export default {
    command: 'mute',
    aliases: ['silence'],
    category: 'admin',
    description: 'Mute the group for a specified duration',
    usage: '.mute [duration in minutes]',
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const durationInMinutes = args[0] ? parseInt(args[0], 10) : undefined;
        try {
            await sock.groupSettingUpdate(chatId, 'announcement');
            if (durationInMinutes !== undefined && durationInMinutes > 0) {
                const durationInMilliseconds = durationInMinutes * 60 * 1000;
                await sock.sendMessage(chatId, {
                    text: `GROUP OFF ASE ADMIN ON KORA OBDI OPEEKKA KORUN ${durationInMinutes} minutes.`,
                    ...channelInfo
                }, { quoted: message });
                setTimeout(async () => {
                    try {
                        await sock.groupSettingUpdate(chatId, 'not_announcement');
                        await sock.sendMessage(chatId, {
                            text: 'GROUP KULA HOYESE AKHON PRAM KORTE PAREN.',
                            ...channelInfo
                        });
                    }
                    catch (unmuteError) {
                        console.error('Error unmuting group:', unmuteError);
                    }
                }, durationInMilliseconds);
            }
            else {
                await sock.sendMessage(chatId, {
                    text: 'GROUP TA BORTOMANE OFF RAKA HOLO .',
                    ...channelInfo
                }, { quoted: message });
            }
        }
        catch (error) {
            console.error('Error muting/unmuting the group:', error);
            await sock.sendMessage(chatId, {
                text: 'An error occurred while muting/unmuting the group. Please try again.',
                ...channelInfo
            }, { quoted: message });
        }
    }
};
